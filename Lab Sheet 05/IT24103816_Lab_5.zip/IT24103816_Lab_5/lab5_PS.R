setwd("C:/Users/IT24103816/Desktop/LAB_5")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

names(Delivery_Times) <- "Delivery_Time"
breaks <- seq(20, 70, length = 10)

histogram <- hist(Delivery_Times$Delivery_Time,main = "Histogram for Delivery Times",breaks = breaks,right = FALSE, xlab = "Delivery Time (minutes)")

cum.freq <- cumsum(histogram$counts)
new <- c(0, cum.freq)

plot(breaks, new, type = 'l',main = "Cumulative Frequency Polygon for Delivery Times",xlab = "Delivery Time (minutes)",ylab = "Cumulative Frequency",ylim = c(0, max(new)))

points(breaks, new, pch = 16)

cbind(Upper = breaks, CumFreq = new)
