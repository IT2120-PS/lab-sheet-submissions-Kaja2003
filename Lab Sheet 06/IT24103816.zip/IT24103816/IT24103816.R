setwd("C:\\Users\\vaara\\OneDrive\\Desktop\\IT24103816")

n <- 50
p <- 0.85

1 - pbinom(46, n, p)

lambda <- 12

dpois(15, lambda)
